package com.Omnipuppy.OmniPuppyXXMiner;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.CheckBox;

public class MerkleattemptenumActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private WebView merkle_tree_webview;
	private TextView merkle_attempt;
	private TextView hash_string_choreo;
	private TextView blockcompletion;
	private TextView hmac_sign_rt;
	private EditText hmac_thread_temp;
	private TextView ripemd_thread;
	private EditText ripemd_temp;
	private LinearLayout linear5;
	private LinearLayout attempt_signafier;
	private LinearLayout linear7;
	private CheckBox trinity_success;
	private CheckBox merkle_unsuccessful;
	private CheckBox checkbox6;
	private CheckBox exception;
	private CheckBox block_verifier;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.merkleattemptenum);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		merkle_tree_webview = (WebView) findViewById(R.id.merkle_tree_webview);
		merkle_tree_webview.getSettings().setJavaScriptEnabled(true);
		merkle_tree_webview.getSettings().setSupportZoom(true);
		merkle_attempt = (TextView) findViewById(R.id.merkle_attempt);
		hash_string_choreo = (TextView) findViewById(R.id.hash_string_choreo);
		blockcompletion = (TextView) findViewById(R.id.blockcompletion);
		hmac_sign_rt = (TextView) findViewById(R.id.hmac_sign_rt);
		hmac_thread_temp = (EditText) findViewById(R.id.hmac_thread_temp);
		ripemd_thread = (TextView) findViewById(R.id.ripemd_thread);
		ripemd_temp = (EditText) findViewById(R.id.ripemd_temp);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		attempt_signafier = (LinearLayout) findViewById(R.id.attempt_signafier);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		trinity_success = (CheckBox) findViewById(R.id.trinity_success);
		merkle_unsuccessful = (CheckBox) findViewById(R.id.merkle_unsuccessful);
		checkbox6 = (CheckBox) findViewById(R.id.checkbox6);
		exception = (CheckBox) findViewById(R.id.exception);
		block_verifier = (CheckBox) findViewById(R.id.block_verifier);
		
		merkle_tree_webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
