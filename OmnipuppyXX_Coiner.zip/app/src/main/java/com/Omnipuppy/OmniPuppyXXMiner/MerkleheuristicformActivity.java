package com.Omnipuppy.OmniPuppyXXMiner;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CheckBox;

public class MerkleheuristicformActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview14;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear12;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout step_valid;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private TextView driving_pointer;
	private CheckBox block_sector_valid;
	private CheckBox heuristic_token_pro;
	private TextView string_identifier;
	private TextView comp_trackr;
	private TextView driving_identif;
	private TextView step_identi;
	private TextView pivot_identifi;
	private TextView driving_hmac;
	private TextView step_hmac;
	private TextView pivot_hmac;
	private TextView driving_ripemd160;
	private TextView step_ripemd160;
	private TextView pivot_ripemd160;
	private TextView driving_label;
	private CheckBox driver_valid;
	private CheckBox driver_void;
	private TextView step_label;
	private CheckBox step_validity;
	private CheckBox step_void;
	private TextView pivot_label;
	private CheckBox pivot_valid;
	private CheckBox pivot_void;
	private CheckBox trinity_valid;
	private CheckBox block_valid;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.merkleheuristicform);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview14 = (TextView) findViewById(R.id.textview14);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		step_valid = (LinearLayout) findViewById(R.id.step_valid);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		driving_pointer = (TextView) findViewById(R.id.driving_pointer);
		block_sector_valid = (CheckBox) findViewById(R.id.block_sector_valid);
		heuristic_token_pro = (CheckBox) findViewById(R.id.heuristic_token_pro);
		string_identifier = (TextView) findViewById(R.id.string_identifier);
		comp_trackr = (TextView) findViewById(R.id.comp_trackr);
		driving_identif = (TextView) findViewById(R.id.driving_identif);
		step_identi = (TextView) findViewById(R.id.step_identi);
		pivot_identifi = (TextView) findViewById(R.id.pivot_identifi);
		driving_hmac = (TextView) findViewById(R.id.driving_hmac);
		step_hmac = (TextView) findViewById(R.id.step_hmac);
		pivot_hmac = (TextView) findViewById(R.id.pivot_hmac);
		driving_ripemd160 = (TextView) findViewById(R.id.driving_ripemd160);
		step_ripemd160 = (TextView) findViewById(R.id.step_ripemd160);
		pivot_ripemd160 = (TextView) findViewById(R.id.pivot_ripemd160);
		driving_label = (TextView) findViewById(R.id.driving_label);
		driver_valid = (CheckBox) findViewById(R.id.driver_valid);
		driver_void = (CheckBox) findViewById(R.id.driver_void);
		step_label = (TextView) findViewById(R.id.step_label);
		step_validity = (CheckBox) findViewById(R.id.step_validity);
		step_void = (CheckBox) findViewById(R.id.step_void);
		pivot_label = (TextView) findViewById(R.id.pivot_label);
		pivot_valid = (CheckBox) findViewById(R.id.pivot_valid);
		pivot_void = (CheckBox) findViewById(R.id.pivot_void);
		trinity_valid = (CheckBox) findViewById(R.id.trinity_valid);
		block_valid = (CheckBox) findViewById(R.id.block_valid);
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
