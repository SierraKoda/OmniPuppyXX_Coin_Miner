package com.Omnipuppy.OmniPuppyXXMiner;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.CheckBox;

public class ObjectvariableheurisActivity extends Activity {
	
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private CheckBox checkbox23;
	private LinearLayout linear12;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout merkle_trinity;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout user_ver;
	private CheckBox checkbox22;
	private CheckBox checkbox24;
	private CheckBox checkbox25;
	private CheckBox checkbox2;
	private CheckBox checkbox3;
	private CheckBox checkbox4;
	private CheckBox checkbox5;
	private CheckBox checkbox6;
	private CheckBox checkbox7;
	private CheckBox checkbox8;
	private CheckBox checkbox9;
	private CheckBox checkbox10;
	private CheckBox checkbox11;
	private CheckBox checkbox12;
	private CheckBox checkbox13;
	private CheckBox checkbox14;
	private CheckBox checkbox15;
	private CheckBox checkbox17;
	private CheckBox checkbox18;
	private CheckBox ai_valid;
	private CheckBox checkbox19;
	private CheckBox checkbox20;
	private CheckBox checkbox21;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.objectvariableheuris);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		checkbox23 = (CheckBox) findViewById(R.id.checkbox23);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		merkle_trinity = (LinearLayout) findViewById(R.id.merkle_trinity);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		user_ver = (LinearLayout) findViewById(R.id.user_ver);
		checkbox22 = (CheckBox) findViewById(R.id.checkbox22);
		checkbox24 = (CheckBox) findViewById(R.id.checkbox24);
		checkbox25 = (CheckBox) findViewById(R.id.checkbox25);
		checkbox2 = (CheckBox) findViewById(R.id.checkbox2);
		checkbox3 = (CheckBox) findViewById(R.id.checkbox3);
		checkbox4 = (CheckBox) findViewById(R.id.checkbox4);
		checkbox5 = (CheckBox) findViewById(R.id.checkbox5);
		checkbox6 = (CheckBox) findViewById(R.id.checkbox6);
		checkbox7 = (CheckBox) findViewById(R.id.checkbox7);
		checkbox8 = (CheckBox) findViewById(R.id.checkbox8);
		checkbox9 = (CheckBox) findViewById(R.id.checkbox9);
		checkbox10 = (CheckBox) findViewById(R.id.checkbox10);
		checkbox11 = (CheckBox) findViewById(R.id.checkbox11);
		checkbox12 = (CheckBox) findViewById(R.id.checkbox12);
		checkbox13 = (CheckBox) findViewById(R.id.checkbox13);
		checkbox14 = (CheckBox) findViewById(R.id.checkbox14);
		checkbox15 = (CheckBox) findViewById(R.id.checkbox15);
		checkbox17 = (CheckBox) findViewById(R.id.checkbox17);
		checkbox18 = (CheckBox) findViewById(R.id.checkbox18);
		ai_valid = (CheckBox) findViewById(R.id.ai_valid);
		checkbox19 = (CheckBox) findViewById(R.id.checkbox19);
		checkbox20 = (CheckBox) findViewById(R.id.checkbox20);
		checkbox21 = (CheckBox) findViewById(R.id.checkbox21);
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
